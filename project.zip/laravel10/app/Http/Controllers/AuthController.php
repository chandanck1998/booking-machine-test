<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    public function login_view()
    {
        return view('auth.login');
    }

    public function register_view()
    {
        return view('auth.register');
    }


    public function login(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'password' => 'required|string',
        ]);

        if(!Auth::attempt(['email'=>$request->email,'password'=>$request->password],true)){
            return back()->withErrors(['message'=>'Failed to create account, please try in a while.']);
        }else{
            return redirect()->route('home');
        }
    }
    
    public function logout()
    {
        Auth::logout();
        return redirect()->route('login');
    }

    public function register(Request $request)
    {
        $request->validate([
            'name' => 'required|string',
            'email' => 'required|email|unique:users',
            'password' => 'required|string',
        ]);

        $response = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
        ]);

        if($response){
            if(!Auth::attempt(['email'=>$request->email,'password'=>$request->password],true)){
                return back()->withErrors(['message'=>'Failed to create account, please try in a while.']);
            }else{
                return redirect()->route('home');
            }
        }else{
            return back()->withErrors(['message'=>'Failed to create account, please try in a while.']);
        }
    }
}
