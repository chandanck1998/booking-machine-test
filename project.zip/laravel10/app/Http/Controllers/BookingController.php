<?php

namespace App\Http\Controllers;

use App\Models\Booking;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class BookingController extends Controller
{
    public function list()
    {
        $data = User::whereId(Auth::user()->id)->with('bookings')->first();
        return view('bookings', compact(['data']));
    }
    public function index()
    {
        $reponse = Booking::where('user_id', Auth::user()->id)->orderBy('id','DESC')->get();
        if (count($reponse) > 0) {
            $allData = [];
            foreach ($reponse as $data) {
                $now = Carbon::now('GMT+5:30');
                if ($now->isAfter($data->expected_time)) {
                    $data->expired = 1;
                } else {
                    $data->expired = 0;
                }

                $data->created_at_me = Carbon::parse($data->created_at, 'GMT+5:30')->format('Y-m-d g:i a');
                $data->expected = Carbon::parse($data->expected_time, 'GMT+5:30')->format('Y-m-d g:i a');

                array_push($allData, $data);
            }
            return response()->json($allData, 200);
        } else {
            return response()->json(['message' => 'No records found'], 404);
        }
    }

    public function create(Request $request, $id)
    {
        $user = Auth::user();
        $date = Carbon::now('GMT+5:30')->format('Y-m-d');
        $slot = $request->slot;
        $expected_time = $this->expectedDate($slot);

        $reponse = Booking::insert([
            'user_id' => $user->id,
            'restaurant' => $id,
            'date' => $date,
            'expected_time' => $expected_time,
            'slot' => $slot,
            'created_at' => Carbon::now('GMT+5:30'),
            'updated_at' => Carbon::now('GMT+5:30'),
        ]);

        if ($reponse) {
            return response()->json(['message' => 'You have successfully book a Reservation'], 200);
        } else {
            return response()->json(['message' => 'Failed to book a Reservation'], 404);
        }
    }

    public function expectedDate($slot)
    {
        // $cutTime = '11:00 am';
        // $cutTime = Carbon::parse($cutTime,'GMT+5:30');
        $time = Carbon::parse($slot, 'GMT+5:30');
        $cTime = Carbon::now('GMT+5:30');

        // return $time >= $cutTime;
        if ($cTime->gt($time)) {
            return $time->addDay(1);
        } else {
            return $time;
        }
    }



    public function checkBooking(Request $request, $id)
    {
        $slot = $request->slot;
        $reponse = Booking::where(['restaurant' => $id, 'slot' => $slot])->first();
        if ($reponse) {
            // return 1;
            $now = Carbon::now('GMT+5:30');
            if ($now->isAfter($reponse->expected_time)) {
                return  0;
            } else {
                return  1;
            }
        } else {
            return 0;
        }
    }

    public function verifySlot($id, $slot)
    {
        return $id . ' - ' . $slot;
        $reponse = Booking::where(['restaurant' => $id, 'slot' => $slot, 'status' => 'status']);
        $now = Carbon::now();
        if ($now->isAfter($reponse->date)) {
            return response()->json(['message' => 'Your OTP has been expired'], 404);
        }
    }
}
