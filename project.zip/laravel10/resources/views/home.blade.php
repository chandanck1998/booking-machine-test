@extends('layout')
@section('content')
<div class="row">
    <div class="col-md-6 col-lg-4 col-sm-6 mx-auto listed">
        <!-- <div class="card">
            <div class="card-body p-2">
                <div class="row">
                    <div class="col-md-4 col-5">
                        <img src="{{ asset('asset/image/bg.jpg') }}" width="100%" alt="">
                    </div>
                    <div class="col-md-8 col-7">
                        <div class="d-flex justify-content-between">
                            <strong>KAKA KA DHABA</strong>
                            <i class="fa fa-star"><small class="text-dark">3/5</small></i>
                        </div>
                        <p class="description">
                            Vero ipsum vero at justo magna kasd ea et. No dolor sit tempor no ut rebum, dolor justo rebum et.
                        </p>
                    </div>
                </div>
                <div class="mt-3">
                    <i class="fas fa-map-marker-alt"></i>
                    <small class="text-primary">Saloni, Baloda Bazar, Chhattisgarh</small>
                </div>

                <div class="mt-2">
                    <i class="far fa-clock"></i>
                    <small>
                        <b>Time Slots</b>
                    </small>
                    <hr class="my-1 mb-2">
                    <div class="time-slot">
                        <span title="Available for booking">10:30PM</span>
                        <span class="booked" title="Booked">10:30PM</span>
                    </div>
                </div>
            </div>
        </div> -->
    </div>
</div>
@endsection
@section('js')
<script src="{{ asset('/asset/main.js') }}"></script>
@endsection