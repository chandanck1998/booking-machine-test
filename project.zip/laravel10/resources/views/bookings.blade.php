@extends('layout')
@section('content')
<div class="row">
    <div class="col-md-6 col-lg-4 col-sm-6 mx-auto bookList">
        <div class="alert alert-primary text-center">
            <i class="fa fa-spinner fa-spin"></i> Loading...
        </div>
    </div>
</div>
@endsection
@section('js')
<script src="{{ asset('/asset/book.js') }}"></script>
@endsection