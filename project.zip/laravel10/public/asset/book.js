$(document).ready(function () {
    // $.ajax({
    //     type: "POST",
    //     headers: { 'x-api-key': 'NB10SKS20AS30' },
    //     url: '/asset/request.json',
    //     data: {
    //         date: '2023-03-14',
    //         time: '10.30',
    //         person: '2',
    //         latitude: '53.798407',
    //         longitude: '-1.548248',
    //     }
    // }).done((response) => {
    //     if (response.status == 1) {
    //         showRecord(response.listed);
    //     }
    // }).fail((error) => {
    //     console.log(error);
    // });

    $.ajax({
        type: "GET",
        url: '/book',
    }).done((response) => {
        console.log(response);
        $(document).find('.bookList').html('');
        response.forEach(function (data) {
            showRecord(data);
        });
    }).fail((error) => {
        console.log(error);
        $(document).find('.bookList').html(`<div class="alert alert-danger text-center">
        <i class="fa fa-exclamation-triangle"></i> No Record found
    </div>`);
    });


    function showRecord(data) {

        var id = data.restaurant;
        $.ajax({
            type: "POST",
            headers: { 'x-api-key': 'NB10SKS20AS30' },
            url: '/asset/request.json',
            data: {
                date: '2023-03-14',
                time: '10.30',
                person: '2',
                latitude: '53.798407',
                longitude: '-1.548248',
            }
        }).done((response) => {
            response.listed.forEach(function (record) {
                if (record.id == id) {
                    var alert = data.expired == 1 ? 'alert alert-danger' : 'alert alert-success';
                    var expired = data.expired == 1 ? 'Expired' : 'Active';
                    var ui = `
                        <div class="`+ alert + `" list="` + id + `" >
                            <small class='text-primary'> <i class='far fa-clock'></i> `+ data.created_at_me + `</small>
                            <br>
                            <div class="row">
                                <div class="col-md-4 col-5">
                                    <img src="`+ record.image + `" width="100%" alt="">
                                </div>
                                <div class="col-md-8 col-7">
                                    <div class="d-flex justify-content-between">
                                        <strong>`+ record.business_name + `</strong>
                                        <i class="fa fa-star"><small class="text-dark">`+ record.rating + `/5</small></i>
                                    </div>
                                    <p class="description">
                                    `+ record.description + `
                                    </p>
                                </div>
                            </div>
                            <hr class="mb-1">
                            <div> 
                                <small><b>Expected In : </b>`+ data.expected + `</small>
                                <br>
                                <small><b>Status : </b>`+ expired + `</small>
                            </div>
                        </div>
                    `;

                    $(document).find('.bookList').append(ui);
                }
            });
        }).fail((error) => {
            console.log(error);
        });
    }
});