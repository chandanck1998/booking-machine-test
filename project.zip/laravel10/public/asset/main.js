$(document).ready(function () {

    // $.ajax({
    //     type: "POST",
    //     headers: { 'x-api-key': 'NB10SKS20AS30' },
    //     url: 'https://igmiweb.com/gladdenhub/Api/search_table',
    //     data: {
    //         date: '2023-03-14',
    //         time: '10.30',
    //         person: '2',
    //         latitude: '53.798407',
    //         longitude: '-1.548248',
    //     }
    // }).done((response)=>{
    //     console.log(response);
    // }).fail((error)=>{
    //     console.log(error);
    // });

    $.ajax({
        type: "POST",
        headers: { 'x-api-key': 'NB10SKS20AS30' },
        url: '/asset/request.json',
        data: {
            date: '2023-03-14',
            time: '10.30',
            person: '2',
            latitude: '53.798407',
            longitude: '-1.548248',
        }
    }).done((response) => {
        if (response.status == 1) {
            showRecord(response.listed);
            // response.listed.forEach(function(data){
            //     showRecord(data);
            // });
        }
    }).fail((error) => {
        console.log(error);
    });


    // SHOW RECORDS

    function showRecord(listed) {
        // console.log(listed);

        listed.forEach((record) => {
            // console.log(record);

            time_available = '';
            if (record.time_available.length > 0) {
                var restaurant = record.id;
                time_available += `<p><i classs='fa fa-spinner fa-spin'></i> Loading..</p>`;
            } else {
                time_available = `<p title="Available for booking">Not Available</p>`;
            }

            var ui = `
                <div class="card mb-2">
                    <div class="card-body p-2">
                        <div class="row">
                            <div class="col-md-4 col-5">
                                <img src="`+ record.image + `" width="100%" alt="">
                            </div>
                            <div class="col-md-8 col-7">
                                <div class="d-flex justify-content-between">
                                    <strong>`+ record.business_name + `</strong>
                                    <i class="fa fa-star"><small class="text-dark">`+ record.rating + `/5</small></i>
                                </div>
                                <p class="description">
                                `+ record.description + `
                                </p>
                            </div>
                        </div>
                        <div class="mt-3">
                            <i class="fas fa-map-marker-alt"></i>
                            <small class="text-primary">`+ record.address + `</small>
                        </div>

                        <div class="mt-2">
                            <i class="far fa-clock"></i>
                            <small>
                                <b>Time Slots</b>
                            </small>
                            <hr class="my-1 mb-2">
                            <div class="time-slot" list='`+ record.id + `'>
                                `+ time_available + `
                            </div>
                        </div>
                    </div>
                </div>
            `;
            // alert(record.id);


            $('div.listed').append(ui);

            listSlots(record.id,record.time_available);
        });
    }

    // function showRecord(listed) {
    //     // console.log(listed);

    //     listed.forEach((record) => {
    //         // console.log(record);

    //         time_available = '';
    //         if (record.time_available.length > 0) {
    //             var restaurant = record.id;
    //             time_available += `<p><i classs='fa fa-spinner fa-spin'></i> Loading..</p>`;
    //         } else {
    //             time_available = `<p title="Available for booking">Not Available</p>`;
    //         }

    //         var ui = `
    //             <div class="card mb-2">
    //                 <div class="card-body p-2">
    //                     <div class="row">
    //                         <div class="col-md-4 col-5">
    //                             <img src="`+ record.image + `" width="100%" alt="">
    //                         </div>
    //                         <div class="col-md-8 col-7">
    //                             <div class="d-flex justify-content-between">
    //                                 <strong>`+ record.business_name + `</strong>
    //                                 <i class="fa fa-star"><small class="text-dark">`+ record.rating + `/5</small></i>
    //                             </div>
    //                             <p class="description">
    //                             `+ record.description + `
    //                             </p>
    //                         </div>
    //                     </div>
    //                     <div class="mt-3">
    //                         <i class="fas fa-map-marker-alt"></i>
    //                         <small class="text-primary">`+ record.address + `</small>
    //                     </div>

    //                     <div class="mt-2">
    //                         <i class="far fa-clock"></i>
    //                         <small>
    //                             <b>Time Slots</b>
    //                         </small>
    //                         <hr class="my-1 mb-2">
    //                         <div class="time-slot" list='`+ record.id + `'>
    //                             `+ time_available + `
    //                         </div>
    //                     </div>
    //                 </div>
    //             </div>
    //         `;
    //         // alert(record.id);


    //         $('div.listed').append(ui);

    //         listSlots(record.id,record.time_available);
    //     });
    // }


    // LISTING TIME SLOT
    
    function listSlots(id,time_available) {

        var time_slot =  $(document).find('div.time-slot[list="'+id+'"]');
        // time_slot.html('');
        var ui = '';
        time_available.forEach((times) => {
            $.ajax({
                type: "GET",
                url: '/book/' + id,
                data: {
                    slot: times.time,
                }
            }).done((response) => {
                // console.log(response); return false;
                if (response == 1) {
                    ui += `<span class='booked' title="Not available for booking">` + times.time + `</span>`;
                } else if (response == 0) {
                    ui += `<span title="Available for booking">` + times.time + `</span>`;
                }
                // console.log(time);

                time_slot.html(ui);
            }).fail((error) => {
                console.log(error); return false;
            })
        });
    }


    // BOOKING
    $(document).on('click', 'div.time-slot span', function () {
        if(!$(this).hasClass('booked')){
            var id = $(this).parent().attr('list');
            var slot = $(this).html();
            bookSlot(this, id, slot);
        }else{
            toastr.warning('Slot has been taken');
        }
    });

    function bookSlot(element,id, slot) {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            type: "POST",
            url: '/book/' + id,
            data: {
                slot: slot,
            }
        }).done((response) => {
            $(element).addClass('booked');
            // alert('Your selected slot is booked');
            toastr.success(response.message);
        }).fail((error) => {
            if('responseJSON' in error){
                if('message' in error.responseJSON){
                    toastr.success(error.responseJSON.message);
                }
            }
            console.log(error);
        });
    }
});