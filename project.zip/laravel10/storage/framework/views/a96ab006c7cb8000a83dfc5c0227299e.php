<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking</title>

    <!-- STYLESEET -->
    <link rel="stylesheet" href="<?php echo e(asset('/asset/main.css')); ?>">
</head>
<body>
    


    <script src="<?php echo e(asset('/asset/main.js')); ?>"></script>
</body>
</html><?php /**PATH C:\Users\Gaharwar Ji\Desktop\test_me\resources\views/welcome.blade.php ENDPATH**/ ?>