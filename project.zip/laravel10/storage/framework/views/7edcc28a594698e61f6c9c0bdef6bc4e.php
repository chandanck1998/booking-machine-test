
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-6 col-lg-4 col-sm-6 mx-auto bookList">
        <div class="alert alert-primary text-center">
            <i class="fa fa-spinner fa-spin"></i> Loading...
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('/asset/book.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Gaharwar Ji\Desktop\test_me\resources\views/bookings.blade.php ENDPATH**/ ?>