<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\BookingController;
use App\Models\Booking;
use Illuminate\Support\Facades\Route;

use function GuzzleHttp\Promise\all;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('home');
})->name('home')->middleware('auth');

Route::group(['middleware'=>'guest'],function(){
    Route::controller(AuthController::class)->group(function(){
        Route::get('/login','login_view')->name('login');
        Route::get('/register','register_view')->name('register');

        Route::post('/login','login')->name('login');
        Route::post('/register','register')->name('register');
    });
});

Route::group(['middleware'=>'auth'],function(){
    Route::controller(AuthController::class)->group(function(){
        Route::get('/logout','logout')->name('logout');
    });
    
    Route::controller(BookingController::class)->group(function(){
        Route::get('/my-reservation','list')->name('reservation');
        Route::post('/book/{id}','create');
        Route::get('/book/{id}','checkBooking');
        Route::get('/book','index');
    });
});